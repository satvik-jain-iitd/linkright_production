---
name: interview-coach
description: >
  AI-powered interview coaching system. Use this skill whenever a user wants to
  prepare for a job interview, practice answering interview questions, get
  coached on how to present their experience, or wants their career stories
  stress-tested by a mock interviewer. Trigger when user mentions "interview
  prep", "interview coaching", "mock interview", "how do I answer X", "prepare
  for a role at [company]", uploads career documents and asks how to speak about
  them, or shares a job description and wants to practice. Also trigger when a
  user uploads any career document (resume, project deck, PPT, PDF, markdown
  dump) and asks how to explain their experience. This skill handles the entire
  pipeline from career document ingestion → structured YAML profiling → question
  generation → answer drafting → Truth Engine validation → optional deep-dive
  stress test → JSON nugget extraction.
---

# Interview Coach Skill

A structured, multi-phase interview preparation system. Guides the user from raw
career documents all the way to validated, interview-ready answers — with an
optional stress-test layer using trick and aggressive follow-up questions.

---

## Phase Overview

```
Phase 0  →  Intake          (role, company, JD upload)
Phase 1  →  YAML Profiling  (job_requirements, user_profile, company)
Phase 2  →  Q Generation    (Top 10 interview questions)
Phase 3  →  Answer Drafting (natural, first-person, story-driven answers)
Phase 4  →  Truth Engine    (validate every answer with user before finalizing)
Phase 5  →  Output          (validated markdown file with Q&As)
Phase 6  →  Deep Dive       (50 follow-up questions: 3 probable + 2 trick each)
Phase 7  →  Nugget Extract  (JSON file of atomic career facts)
```

Always execute phases in order. Never skip Phase 4 (Truth Engine validation).

---

## Phase 0: Intake

### 0.1 — Ask for Target Role and Company

Use the `ask_user_input_v0` tool to collect:

```
Question 1: "What role are you targeting?" (mandatory, free text)
Question 2: "Do you have a target company in mind?" (optional, free text or "Not yet")
```

If the user provides a company name → proceed to **0.2**.
If no company → skip to **Phase 1** with company = null.

### 0.2 — Ask for Job Description

Say:
> "Great! Do you have the specific JD for this role at [Company]? You can paste
> it as text or upload it as a PDF/doc. If you don't have it, I can work without
> it."

If JD provided → include in Phase 1 YAML generation.
If no JD → set jd_available = false, proceed with role title + company research only.

### 0.3 — Confirm Career Documents

Check what documents the user has already uploaded in this conversation (PDFs,
PPTs, markdown files, plain text dumps). If none detected, say:
> "Please share your career documents — this can be your resume, project decks,
> any notes you've written about your work, or a raw text dump of your
> experiences. Any format is fine."

Once at least one career document is available → proceed to Phase 1.

### 0.4 — Collect LinkRight Session Token (for graph dispatch in Phase 9)

Ask:
> "One last thing — do you have your LinkRight session code? It looks like
> LR-XXXXXXXX. You can get it from sync.linkright.in → onboarding → Generate
> Code, or Settings → LifeOS → Generate Code. If you don't have one, that's
> fine — we can skip the graph save at the end."

If provided → store as `session_token`. Set `has_session_token = true`.
If skipped → set `has_session_token = false`. Phases 8–9 will be skipped.

---

## Phase 1: YAML Profiling

Read all available inputs:
- Career documents (uploaded files — use markitdown or pdf extraction as needed;
  see references/file_reading_guide.md)
- JD text (if provided)
- Target role and company

Generate **three YAML files** and save them to `/home/claude/`:

### 1.1 — `job_requirements.yaml`

```yaml
role: "<exact role title>"
company: "<company name or null>"
seniority: "<junior/mid/senior/lead/director>"
role_type: "<behavioral_heavy/technical_heavy/balanced>"

must_have_skills:
  - "<skill 1>"
  - "<skill 2>"

nice_to_have_skills:
  - "<skill 1>"

key_responsibilities:
  - "<responsibility 1>"
  - "<responsibility 2>"

interview_focus_areas:
  - "<focus area 1 derived from JD or role research>"

leadership_expectations: "<none/team_lead/program_lead/org_lead>"
```

### 1.2 — `user_profile.yaml`

Extract from career documents:

```yaml
name: "<user's name if found, else 'Candidate'>"
current_role: "<current job title>"
current_company: "<current employer>"
years_of_experience: <integer>

top_stories:
  - title: "<story title>"
    company: "<company>"
    situation: "<one sentence>"
    action: "<what they did>"
    result: "<measurable outcome>"
    tags: ["<skill>", "<theme>"]

skills_demonstrated:
  - "<skill 1>"
  - "<skill 2>"

gaps_vs_jd:
  - "<skill or experience gap detected>"

strengths_for_role:
  - "<why this person fits>"
```

### 1.3 — `company.yaml`

If company is known, populate from your knowledge. If JD provided, extract
additional signals.

```yaml
company: "<name>"
industry: "<industry>"
size: "<startup/mid/large/enterprise>"
known_values:
  - "<value 1>"
  - "<value 2>"
what_they_look_for_in_this_role:
  - "<trait or behavior 1>"
  - "<trait or behavior 2>"
interview_style: "<structured/case-based/behavioral/technical/mixed>"
culture_notes: "<1-2 sentence summary of culture>"
```

After generating all three YAMLs, briefly summarize them to the user in
conversational prose (2-3 sentences each). Do NOT dump raw YAML in chat —
just the narrative summary.

---

## Phase 2: Question Generation

Using the three YAMLs as inputs, architect the **Top 10 Interview Questions**.

### Question Balance Rules

Derive the right mix from `job_requirements.yaml → role_type`:

| Role Type | Behavioral | Technical | Situational | Leadership |
|-----------|-----------|-----------|-------------|------------|
| behavioral_heavy | 5 | 1 | 2 | 2 |
| technical_heavy | 2 | 5 | 2 | 1 |
| balanced | 3 | 3 | 2 | 2 |

### Question Design Rules

- Each question must map to at least one `must_have_skill` or `key_responsibility`
  from `job_requirements.yaml`
- Each question must be answerable using at least one story from
  `user_profile.yaml → top_stories`
- Cover all P0/P1 priority stories from the user's profile
- If a gap exists in `gaps_vs_jd`, include 1 question that surfaces it so we
  can prepare a framing

### Question Format (internal, not shown to user yet)

```yaml
q_id: Q01
question: "<the question text>"
type: behavioral / technical / situational / leadership
jd_mapping: "<which JD requirement this tests>"
user_story_to_use: "<which story from user_profile.yaml fits best>"
difficulty: easy / medium / hard
```

Do not show this YAML to user. Use it only to drive Phase 3.

---

## Phase 3: Answer Drafting

For each of the 10 questions, draft a **natural, first-person answer** as if
the user is speaking it aloud in a real interview.

### Answer Quality Rules

- Sound like a human speaking, NOT a resume being read
- Use STAR structure internally but DO NOT label it (no "Situation:", "Action:")
- Include specific metrics, names, and outcomes from career documents
- Length: 150-250 words per answer (speaking pace ~90 seconds)
- Avoid filler phrases: "basically", "kind of", "you know" (unless Hinglish
  coaching mode — see references/hinglish_coaching_guide.md)
- End each answer with a forward-looking or reflective sentence
- If multiple stories could apply, pick the strongest one and note the
  alternative

### Answer Template (internal)

```
[Hook — 1 sentence that grabs attention]
[Context — role, team, situation in 2-3 sentences]
[What I did — specific actions, 3-4 sentences]
[The result — quantified outcome]
[Reflection/Takeaway — 1 sentence]
```

Present Q&A pairs to user one at a time during Phase 4.

---

## Phase 4: Truth Engine Validation

**This phase is mandatory. Never skip it.**

Based on the E5 Truth Engine methodology, validate every answer before
finalizing. For each question-answer pair:

### 4.1 — Pre-Validation Check

Before showing the answer to the user, internally verify:

```
CONFLICT CHECK:
- Does this answer contradict any other answer drafted so far?
- Does it reference a date/metric that conflicts with another story?

CREDIBILITY CHECK:
- Is every claim in this answer supported by the career documents?
- Is any claim an inference (not stated directly)?

HALLUCINATION PREVENTION:
- No fabricated metrics (only use numbers from source documents)
- No invented company names, team names, or project names
- No synthesis of conflicting information as a single fact
- If groundedness < 0.7 → flag for user instead of presenting
```

If any check fails → fix the answer before presenting.

### 4.2 — User Validation (per question)

For each Q&A pair, present in this format:

```
──────────────────────────────────
Q[N]: [Question text]

MY UNDERSTANDING OF YOUR EXPERIENCE:
[Answer draft]

Is this an accurate reflection of what you actually did?
- ✅ Yes, this is correct
- 🔧 Partially right — let me correct something
- ❌ No, this isn't accurate
──────────────────────────────────
```

Use `ask_user_input_v0` with options: ["✅ Looks good", "🔧 Needs correction", "❌ Not accurate"]

**If user selects ✅**: Mark answer as `validated: true` in memory. Move to next question.

**If user selects 🔧 or ❌**: Ask "What should be corrected?" — collect correction,
revise the answer, re-present. Repeat until user validates.

**Never proceed to Phase 5 until ALL 10 answers have been validated.**

### 4.3 — Conflict Resolution Across Answers

After all 10 are validated, run a final cross-check:
- Any metrics that contradict across answers? → Flag to user
- Any story used twice with different details? → Align and re-confirm

---

## Phase 5: Output — Validated Interview Guide

Once all 10 answers are validated, generate the final output file:

**File**: `/mnt/user-data/outputs/interview_guide_[role]_[company].md`

### Output File Structure

```markdown
# Interview Guide: [Role] at [Company]
**Generated**: [date]
**Validated**: Yes — all answers confirmed by candidate

---

## My Profile Summary
[2-3 sentence elevator pitch derived from user_profile.yaml]

---

## Top 10 Interview Questions & Answers

### Q1: [Question]
**Why they'll ask this**: [1 sentence — maps to which JD requirement]
**Best story to use**: [story title from user_profile.yaml]

**My Answer**:
[Full validated answer]

---
[Repeat for Q2-Q10]

---

## My Key Metrics to Remember
[Bulleted list of all numbers/metrics used across answers — quick reference]

## Stories I Can Reuse
[Table: Story → Questions it applies to]
```

Present file using `present_files` tool. Then ask:

```
"Your validated interview guide is ready! 

Would you like to go deeper? I can generate 5 follow-up questions for each of
these 10 questions — including 2 trick/stress-test questions that aggressive
interviewers might throw at you.

Want to do the deep dive? (Yes / No)"
```

---

## Phase 6: Deep Dive — Follow-Up Questions

Only execute if user explicitly says yes.

### For each of the 10 questions, generate 5 follow-up questions:

**Questions 1-3: High Probability Follow-Ups**
Normal, curious interviewer. Wants to go deeper. Professional, polite tone.
Examples:
- "Can you walk me through the specific methodology you used?"
- "What would you do differently if you had to do it again?"
- "How did you measure success?"

**Questions 4-5: Stress Test / Trick Questions**
Skeptical or aggressive interviewer. May be blunt, challenging, or provocative.
Maintains one of the following personas (vary across questions):

```yaml
personas:
  skeptic:
    tone: "Politely doubtful. Questions whether you actually led vs. contributed."
    example: "That sounds like a team effort — what specifically was YOUR contribution?"

  aggressive:
    tone: "Direct and challenging. Puts you on the defensive."
    example: "Your recommendation was for in-house build but vendors exist for a reason.
               How do you know you didn't just choose the cheaper, riskier option?"

  gotcha:
    tone: "Catches inconsistencies or gaps in your answer."
    example: "You said you got buy-in, but who specifically pushed back and why?"

  stress_test:
    tone: "Tests composure under pressure. May seem rude."
    example: "Honestly that sounds pretty basic for a senior role. What's impressive about it?"
```

### Follow-Up Answer Drafting Rules

- For Q1-Q3 follow-ups: draft concise answers (60-90 words)
- For Q4-Q5 follow-ups: draft answers that demonstrate composure, don't get
  defensive, bridge back to strengths
- Always validate follow-up answers with user using the same Truth Engine loop
  (Phase 4 mini-loop)

### Deep Dive Output File

**File**: `/mnt/user-data/outputs/interview_guide_deep_dive_[role]_[company].md`

Same structure as Phase 5 output but with follow-up sections under each Q.

---

## Phase 7: Nugget Extraction (Optional)

After deep dive is complete (or after Phase 5 if user skips deep dive), ask:

```
"Want me to also extract your career highlights as structured data?
This creates a JSON file of atomic career facts — useful for building
your story bank or feeding into other tools."
```

If yes → extract nuggets using the canonical JSON schema.
Read the schema from: `references/nugget_schema.md` before extracting.

Rules:
- One achievement per nugget (atomic)
- Every work_experience nugget MUST have company + role fields
- All metrics from source documents MUST appear in the answer field
- event_date MUST be YYYY-MM-DD (use YYYY-01-01 if only year known,
  YYYY-MM-01 if only month known)
- Validate JSON before writing: `python3 -c "import json; json.load(open('file.json'))"`

**File**: `/mnt/user-data/outputs/career_nuggets_[timestamp].json`

---

## File Management

```
/home/claude/
├── job_requirements.yaml     (Phase 1)
├── user_profile.yaml         (Phase 1)
├── company.yaml              (Phase 1)

/mnt/user-data/outputs/
├── interview_guide_[role]_[company].md         (Phase 5)
├── interview_guide_deep_dive_[role]_[company].md  (Phase 6)
└── career_nuggets_[timestamp].json             (Phase 7)
```

---

## Key Guardrails (Always Active)

1. **Never fabricate** — only use facts from uploaded documents
2. **Never skip validation** — Phase 4 is non-negotiable
3. **Never present conflicting claims as fact** — flag to user instead
4. **Always use validated answers** in the final output file
5. **Maintain interviewer persona** in deep dive — do not break character
6. **One question at a time** during validation — don't dump all 10 at once
7. **Hinglish is for coaching narration only** — interview answers stay in English

---

## Reference Files

| File | When to Read |
|------|-------------|
| `references/file_reading_guide.md` | Phase 0 — to extract text from PDFs, PPTs, markdown |
| `references/nugget_schema.md` | Phase 7 — canonical JSON format for career nuggets |
| `references/hinglish_coaching_guide.md` | Optional — if user prefers Hinglish in coaching layer |

---

---

## Phase 8: Atom Transformation

**Trigger:** Phase 7 complete (`nuggets_extracted = true`).
**Skip if:** `has_session_token = false` (user didn't provide LR-XXXXXXXX).

For each nugget from Phase 7 output, derive a CareerAtom object:

```
action_verb         ← first strong past-tense word from nugget_text
                      e.g. "Led 6-month evaluation..." → "Led"
action_detail       ← nugget_text with leading verb removed
company             ← nugget.company (direct copy)
role                ← nugget.role (direct copy)
result_text         ← outcome/metrics portion of nugget.answer
context             ← situational setup portion of nugget.answer
tools_used[]        ← nugget.tags that are technologies or tools
behavioral_tags[]   ← nugget.tags that are behavioral competencies
                      (ownership, delivery, leadership, data-driven, etc.)
skills_demonstrated[] ← all of nugget.tags (superset)
timeframe           ← nugget.event_date converted to "MMM YYYY"
                      e.g. "2024-03-01" → "Mar 2024"
difficulty          ← P0/P1 → "hard" | P2 → "medium" | P3 → "easy"
team_role           ← "team_lead"→"lead" | "individual"→"solo" | "none"→"contributor"
metrics[]           ← extract numeric values from nugget.answer into:
                      [{value, unit, direction, timeframe, confidence}]
                      e.g. "40% reduction in build time" →
                      {value:40, unit:"%", direction:"decreased", confidence:"exact"}
```

**Required fields:** `action_verb`, `action_detail`, `company`, `role`, `result_text` must always be set.
If any required field cannot be derived from the nugget, ask the user for that specific field before continuing.

Show the user the full list of transformed atoms for review.
Ask: "Do these look correct? I'll save them to your LifeOS graph."
Only proceed to Phase 9 after user confirms.

State: `atoms_transformed = true`

---

## Phase 9: Oracle Graph Dispatch

**Trigger:** Phase 8 complete + user confirmed atoms.
**Skip if:** `has_session_token = false`.

Dispatch atoms **one at a time** with a 3-second gap between each.
Do NOT burst-send — Oracle's embedding model needs time between requests.

For each CareerAtom (index N of TOTAL), run Bash:

```bash
curl -s -X POST https://sync.linkright.in/api/oracle/ingest-atom \
  -H "Content-Type: application/json" \
  -d '{"token":"<session_token>","atom":<atom_as_single_line_json>}'
```

After each curl, wait before sending the next atom:
```bash
sleep 5
```

Handle each response immediately after receiving it:
- `{"ok":true, ...}` → print "[N/TOTAL] ✓ [action_verb] [action_detail] — saved"
  Store the `user_id` from the first successful response (needed for session-close).
- `{"conflict":true, ...}` → print "[N/TOTAL] ⚠ Duplicate — skipped"
- HTTP 429 or `{"error":...}` containing "rate limit" → print "⏳ Rate limit hit — waiting 120s before continuing…", run `sleep 120`, then retry this atom once.
- Any other error → print the full error message, ask user: retry this atom or skip?

If TOTAL > 20 atoms: after every 10th atom, add an extra `sleep 30` pause to give Oracle time to catch up.

After all atoms dispatched, close the session:

```bash
curl -s -X POST https://sync.linkright.in/api/oracle/session-close \
  -H "Content-Type: application/json" \
  -d '{"token":"<session_token>","user_id":"<user_id_from_first_ingest>"}'
```

Print final summary:
```
✅ [N] career achievements saved to your LinkRight LifeOS graph.
   [M] duplicates skipped.
   Open sync.linkright.in → Dashboard to see your career profile.
```

State: `dispatch_complete = true`

---

## Quick State Tracker

Maintain this state internally throughout the session:

```
intake_complete: bool
has_session_token: bool        ← NEW: whether LR-XXXXXXXX was provided in Phase 0
session_token: str | null      ← NEW: the LR-XXXXXXXX value
yaml_files_generated: bool
questions_drafted: int (0-10)
answers_validated: int (0-10)
output_file_generated: bool
deep_dive_requested: bool
deep_dive_validated: int (0-50)
nuggets_extracted: bool
atoms_transformed: bool        ← NEW: Phase 8 complete
dispatch_complete: bool        ← NEW: Phase 9 complete
```

Do not show this to user. Use it to know where you are and what comes next.
