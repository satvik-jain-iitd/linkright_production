# File Reading Guide for Interview Coach

## Supported Input Formats

| Format | Extraction Method |
|--------|------------------|
| `.pptx` | `python -m markitdown file.pptx` |
| `.pdf` | `python -m markitdown file.pdf` |
| `.docx` | `python -m markitdown file.docx` |
| `.md` | Read directly (already text) |
| `.txt` | Read directly |
| Pasted text | Already in context — no extraction needed |

## Where Uploaded Files Live

All user uploads are at: `/mnt/user-data/uploads/`

```bash
# List what's available
ls /mnt/user-data/uploads/

# Extract text from any office/pdf file
python -m markitdown /mnt/user-data/uploads/filename.pptx
python -m markitdown /mnt/user-data/uploads/filename.pdf
```

## Install markitdown if needed

```bash
pip install "markitdown[all]" --break-system-packages --quiet
```

## Extraction Tips

- For PPTs: markitdown extracts slide text + speaker notes — speaker notes
  often contain richer context than slide text, so read both
- For PDFs: if markitdown returns garbled text, the PDF may be scanned.
  Try: `pip install pytesseract --break-system-packages` then use OCR approach
- For large documents (>50 pages): extract first, then summarize sections
  before building YAML — don't try to hold entire text in one prompt

## After Extraction

Once you have raw text from all documents, build `user_profile.yaml` by:
1. Identifying every distinct role/company mentioned
2. For each role: extract what was done, what was delivered, what metrics exist
3. Group into top_stories with STAR structure
4. Note any skills or tools mentioned
5. Note any gaps vs the JD
