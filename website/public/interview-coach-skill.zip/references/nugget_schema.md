# Career Nugget JSON Schema

Use this schema exactly when extracting nuggets in Phase 7.
One nugget = one atomic achievement or fact. Never combine two achievements.

## JSON Template

```json
{
  "nugget_text": "One-line atomic fact or achievement",
  "question": "What did [person] achieve/do at [company]?",
  "alt_questions": [
    "Alternative phrasing 1",
    "Alternative phrasing 2"
  ],
  "answer": "Self-contained answer >30 chars. MUST include company, role, timeframe, and any metrics.",
  "primary_layer": "A",
  "section_type": "work_experience",
  "life_domain": null,
  "resume_relevance": 0.9,
  "resume_section_target": "experience",
  "importance": "P1",
  "factuality": "fact",
  "temporality": "past",
  "event_date": "YYYY-MM-DD",
  "company": "Company Name",
  "role": "Exact Job Title at Time of Event",
  "people": ["Collaborator name if mentioned"],
  "tags": ["tag1", "tag2"],
  "leadership_signal": "none"
}
```

## Field Rules

### primary_layer
- `"A"` = Resume-relevant (work, projects, skills, education, certs, awards, volunteer)
- `"B"` = Life context (relationships, health, finance, inner life, logistics, recreation)

### section_type (Layer A only)
`work_experience` | `independent_project` | `skill` | `education` |
`certification` | `award` | `publication` | `volunteer` | `summary` | `contact_info`

### life_domain (Layer B only)
`Relationships` | `Health` | `Finance` | `Inner_Life` | `Logistics` | `Recreation`

### importance
- `P0` = Career-defining (top 3 achievements ever)
- `P1` = Strong supporting evidence
- `P2` = Contextual background
- `P3` = Peripheral detail

### factuality
`fact` | `opinion` | `aspiration`

### temporality
`past` | `present` | `future`

### event_date — CRITICAL
**Always YYYY-MM-DD format. Never YYYY or YYYY-MM alone.**
- If exact date known: use it
- If only month known: use first day → `2024-03-01`
- If only year known: use January first → `2024-01-01`
- If approximate period known: use first month of that period
- If truly unknown: use `2024-01-01` as safe fallback (document this assumption)

### resume_relevance
Float 0.0–1.0. P0 items = 0.95–1.0. P3 items = 0.2–0.4.

### leadership_signal
`none` | `individual` | `team_lead`

### company + role (MANDATORY for work_experience)
Both fields MUST be set. Never null for work_experience nuggets.

## Validation Before Writing

```python
import json

with open('career_nuggets.json', 'r') as f:
    data = json.load(f)

for i, n in enumerate(data):
    assert len(n['answer']) > 30, f"Nugget {i}: answer too short"
    assert n['event_date'] and len(n['event_date']) == 10, f"Nugget {i}: bad date format"
    if n['section_type'] == 'work_experience':
        assert n['company'], f"Nugget {i}: missing company"
        assert n['role'], f"Nugget {i}: missing role"

print(f"✅ All {len(data)} nuggets valid")
```

## Example Nugget

```json
{
  "nugget_text": "Led 6-month CDD vendor evaluation across 15+ vendors, securing buy-in for in-house build",
  "question": "What did Satvik lead at American Express for CDD platform selection?",
  "alt_questions": [
    "How did Satvik approach the build vs buy decision at Amex?",
    "What vendor evaluation did Satvik run in 2024?"
  ],
  "answer": "As Product Owner for CRR Modernization at American Express (Feb–Aug 2024), Satvik led a 6-month evaluation of 15+ vendors, narrowed to 2 finalists (NICE Actimize score 8.93, Symphony AI score 9.04), ran a 3-way POC, and secured stakeholder buy-in for in-house build.",
  "primary_layer": "A",
  "section_type": "work_experience",
  "life_domain": null,
  "resume_relevance": 1.0,
  "resume_section_target": "experience",
  "importance": "P0",
  "factuality": "fact",
  "temporality": "past",
  "event_date": "2024-02-01",
  "company": "American Express",
  "role": "Senior Associate Product Manager / Product Owner, CRR Modernization",
  "people": [],
  "tags": ["vendor-evaluation", "CDD", "CRR", "build-vs-buy", "compliance"],
  "leadership_signal": "team_lead"
}
```
